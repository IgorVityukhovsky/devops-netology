# Дополнительные материалы к лекциям по Ansible

1. [Как работать с Windows](http://onreader.mdl.ru/MasteringAnsible.3ed/content/Ch03.html)
2. [Скачать Elasticsearch](https://www.elastic.co/downloads/elasticsearch)
3. [Скачать Kibana](https://www.elastic.co/downloads/kibana)
4. [Скачать filebeat](https://www.elastic.co/downloads/beats/filebeat)
5. [Все виды beat'ов](https://www.elastic.co/downloads/beats/)